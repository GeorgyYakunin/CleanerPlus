package com.fchatnet.cleaner.model;

public class SDCardInfo {
    public long free;
    public long total;
}
