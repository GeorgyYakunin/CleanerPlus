package com.fchatnet;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.fchatnet.ramboost.R;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.util.List;

import lal.adhish.gifprogressbar.GifView;

public class BatteryOptimizi extends AppCompatActivity {
    android.support.v7.widget.Toolbar mActionBarToolbar;
    private InterstitialAd mInterstitialAd;

    private AdView mAdView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battery_optimizi);
        mActionBarToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mActionBarToolbar);

        mActionBarToolbar.setTitleTextColor(Color.WHITE);

        mActionBarToolbar.setNavigationIcon(R.drawable.bck);
        mActionBarToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });
        GifView pGif = (GifView) findViewById(R.id.progressBar);
        pGif.setImageResource(R.drawable.battery_gif);


        mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.ins1));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
                new KillBackgroundProcessesTask().execute();
                finish();
            }
        },5000);










    }
    private class KillBackgroundProcessesTask extends AsyncTask<Void,Integer,Integer> {
        @Override
        protected Integer doInBackground(Void...Void){
            // Get an instance of PackageManager
            PackageManager pm = getPackageManager();

            // Get an instance of ActivityManager
            ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);

            // Get a list of RunningAppProcessInfo
            List<ActivityManager.RunningAppProcessInfo> list = am.getRunningAppProcesses();

            // Count the number of running processes
            int initialRunningProcessesSize = list.size();

            // Iterate over the RunningAppProcess list
            for(ActivityManager.RunningAppProcessInfo process: list){
                // Ignore, if the process contains package list is empty
                if(process.pkgList.length == 0) continue;

                try{
                    // Get the PackageInfo for current process
                    PackageInfo packageInfo = pm.getPackageInfo(process.pkgList[0],PackageManager.GET_ACTIVITIES);

                    // Ignore the self app package
                    if(!packageInfo.packageName.equals(getApplication().getPackageName())){
                        // Try to kill other background processes
                        // System processes are ignored
                        am.killBackgroundProcesses(packageInfo.packageName);
                    }
                }catch(PackageManager.NameNotFoundException e){
                    // Catch the exception
                    e.printStackTrace();
                }
            }

            // Get the running processes after killing some
            int currentRunningProcessesSize = am.getRunningAppProcesses().size();

            // Return the number of killed processes
            return initialRunningProcessesSize - currentRunningProcessesSize;
        }

        protected void onPostExecute(Integer result){
            // Show the number of killed processes
            Toast.makeText(getApplicationContext(),"Killed : " + result + " processes",Toast.LENGTH_SHORT).show();

            // Refresh the TextView with running processes
            populateTextViewWithRunningProcesses();
        }
    }
    protected void populateTextViewWithRunningProcesses(){
        // Empty the TextView
        //mTextView.setText("");

        // Initialize a new instance of ActivityManager
        ActivityManager am = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);

        // Get a list of RunningAppProcessInfo
        List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();

        // Display the number of running processes
        Toast.makeText(getApplicationContext(),"Running processes : " +
                runningProcesses.size(),Toast.LENGTH_SHORT).show();

        // Loop through the running processes
        for(ActivityManager.RunningAppProcessInfo processInfo: runningProcesses ){
            // Get the process name
            //mTextView.setText(mTextView.getText() + processInfo.processName + "\n");
        }
    }




}
