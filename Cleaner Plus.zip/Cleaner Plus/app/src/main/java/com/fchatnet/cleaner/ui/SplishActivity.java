package com.fchatnet.cleaner.ui;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.fchatnet.Main_Screen;
import com.fchatnet.cleaner.base.BaseActivity;
import com.fchatnet.cleaner.service.CleanerService;
import com.fchatnet.cleaner.service.CoreService;
import com.fchatnet.cleaner.utils.Constants;
import com.fchatnet.cleaner.utils.SharedPreferencesUtils;
import com.fchatnet.ramboost.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;


public class SplishActivity extends BaseActivity {
    public static final String ACTION_INSTALL_SHORTCUT = "com.android.launcher.action.INSTALL_SHORTCUT";
    TextView appName;
    private Animation mFadeIn;
    private Animation mFadeInScale;
    private Animation mFadeOut;
    ImageView mImageView;
    TextView textCopyRight;
    TextView title;
    private InterstitialAd mInterstitialAd;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splish);
        MobileAds.initialize(SplishActivity.this);


        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.ins1));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());




        this.mImageView = (ImageView) findViewById(R.id.image);
        this.appName = (TextView) findViewById(R.id.app_name);
        this.appName.setTypeface(Typeface.createFromAsset(getAssets(), Constants.FONT_MISO_BOLD));
        startService(new Intent(this, CoreService.class));
        startService(new Intent(this, CleanerService.class));
//        if (!SharedPreferencesUtils.isShortCut(this.mContext).booleanValue()) {
//            createShortCut();
//        }
        initAnim();
        setListener();
    }

    private void createShortCut() {
        Intent intent = new Intent();
        intent.setAction(ACTION_INSTALL_SHORTCUT);
        intent.putExtra("android.intent.extra.shortcut.NAME", getString(R.string.app_name));
        intent.putExtra("duplicate", false);
        intent.putExtra("android.intent.extra.shortcut.ICON", BitmapFactory.decodeResource(getResources(), R.drawable.short_cut_icon));
        Intent i = new Intent();
        i.setAction("com.cleanmaster.shortcut");
        i.addCategory("android.intent.category.DEFAULT");
        intent.putExtra("android.intent.extra.shortcut.INTENT", i);
        sendBroadcast(intent);
        SharedPreferencesUtils.setIsShortCut(this.mContext, Boolean.valueOf(true));
    }

    private void initAnim() {
        this.mFadeIn = AnimationUtils.loadAnimation(this, R.anim.welcome_fade_in);
        this.mFadeIn.setDuration(500);
        this.mFadeInScale = AnimationUtils.loadAnimation(this, R.anim.welcome_fade_in_scale);
        this.mFadeInScale.setDuration(2000);
        this.mFadeOut = AnimationUtils.loadAnimation(this, R.anim.welcome_fade_out);
        this.mFadeOut.setDuration(500);
        this.mImageView.startAnimation(this.mFadeIn);
    }

    public void setListener() {
        this.mFadeIn.setAnimationListener(new AnimationListener() {
            public void onAnimationStart(Animation animation) {
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationEnd(Animation animation) {
                SplishActivity.this.mImageView.startAnimation(SplishActivity.this.mFadeInScale);
            }
        });
        this.mFadeInScale.setAnimationListener(new AnimationListener() {
            public void onAnimationStart(Animation animation) {
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationEnd(Animation animation) {

                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();
                        }
                        else
                            {

                                Intent intent = new Intent(SplishActivity.this, Main_Screen.class);
                                startActivity(intent);
                                SplishActivity.this.finish();
                            }
                mInterstitialAd.setAdListener(new AdListener() {

                        @Override public void onAdClosed () {
                            Intent intent = new Intent(SplishActivity.this, Main_Screen.class);
                            startActivity(intent);
                            SplishActivity.this.finish();
                            // Code to be executed when when the interstitial ad is closed.

                        }

                });

            }
        });
        this.mFadeOut.setAnimationListener(new AnimationListener() {
            public void onAnimationStart(Animation animation) {
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationEnd(Animation animation) {
            }
        });
    }
}
